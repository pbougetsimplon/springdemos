package fr.bouget.spring.springpratique01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springpratique01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
