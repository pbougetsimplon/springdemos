package fr.bouget.spring.springpratique01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springpratique01Application {

	public static void main(String[] args) {
		SpringApplication.run(Springpratique01Application.class, args);
	}

}
